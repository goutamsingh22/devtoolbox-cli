"""Colour conversion helpers (hex, RGB and HSL)."""

from __future__ import annotations

import re
from typing import Union

_HEX = re.compile(r"^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")
_RGB = re.compile(r"^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$", re.IGNORECASE)

RGB = tuple[int, int, int]
HSL = tuple[float, float, float]
ColourInfo = dict[str, Union[str, list[Union[int, float]]]]


def _channel(value: int) -> int:
    if not 0 <= value <= 255:
        raise ValueError(f"RGB channel out of range: {value}")
    return value


def hex_to_rgb(value: str) -> RGB:
    """Convert ``#rgb`` or ``#rrggbb`` to an ``(r, g, b)`` tuple."""
    match = _HEX.match(value.strip())
    if not match:
        raise ValueError(f"invalid hex colour: {value!r}")
    digits = match.group(1)
    if len(digits) == 3:
        digits = "".join(char * 2 for char in digits)
    return (
        int(digits[0:2], 16),
        int(digits[2:4], 16),
        int(digits[4:6], 16),
    )


def rgb_to_hex(rgb: RGB) -> str:
    """Convert an ``(r, g, b)`` tuple to a lowercase hex string."""
    red, green, blue = (_channel(value) for value in rgb)
    return f"#{red:02x}{green:02x}{blue:02x}"


def rgb_from_text(value: str) -> RGB:
    """Parse a ``rgb(r, g, b)`` string."""
    match = _RGB.match(value.strip())
    if not match:
        raise ValueError(f"invalid rgb colour: {value!r}")
    return tuple(_channel(int(channel)) for channel in match.groups())  # type: ignore[return-value]


def rgb_to_hsl(rgb: RGB) -> HSL:
    """Convert an ``(r, g, b)`` tuple to ``(hue, saturation, lightness)``.

    Hue is in degrees (0-360); saturation and lightness are percentages.
    """
    red, green, blue = (_channel(value) / 255 for value in rgb)
    maximum = max(red, green, blue)
    minimum = min(red, green, blue)
    lightness = (maximum + minimum) / 2

    if maximum == minimum:
        return 0.0, 0.0, lightness * 100

    delta = maximum - minimum
    saturation = delta / (2 - maximum - minimum) if lightness > 0.5 else delta / (maximum + minimum)

    if maximum == red:
        hue = (green - blue) / delta + (6 if green < blue else 0)
    elif maximum == green:
        hue = (blue - red) / delta + 2
    else:
        hue = (red - green) / delta + 4

    return hue * 60, saturation * 100, lightness * 100


def _hue_to_rgb(p: float, q: float, t: float) -> float:
    if t < 0:
        t += 1
    if t > 1:
        t -= 1
    if t < 1 / 6:
        return p + (q - p) * 6 * t
    if t < 1 / 2:
        return q
    if t < 2 / 3:
        return p + (q - p) * (2 / 3 - t) * 6
    return p


def hsl_to_rgb(hsl: HSL) -> RGB:
    """Convert ``(hue, saturation%, lightness%)`` to an ``(r, g, b)`` tuple."""
    hue, saturation, lightness = hsl
    hue = (hue % 360) / 360
    saturation = max(0.0, min(100.0, saturation)) / 100
    lightness = max(0.0, min(100.0, lightness)) / 100

    if saturation == 0:
        value = round(lightness * 255)
        return value, value, value

    q = (
        lightness * (1 + saturation)
        if lightness < 0.5
        else lightness + saturation - lightness * saturation
    )
    p = 2 * lightness - q
    return (
        round(_hue_to_rgb(p, q, hue + 1 / 3) * 255),
        round(_hue_to_rgb(p, q, hue) * 255),
        round(_hue_to_rgb(p, q, hue - 1 / 3) * 255),
    )


def inspect(value: str) -> ColourInfo:
    """Return hex, RGB and HSL representations of a colour."""
    raw = value.strip()
    rgb = rgb_from_text(raw) if raw.lower().startswith("rgb") else hex_to_rgb(raw)
    hue, saturation, lightness = rgb_to_hsl(rgb)
    return {
        "input": value,
        "hex": rgb_to_hex(rgb),
        "rgb": list(rgb),
        "hsl": [round(hue, 2), round(saturation, 2), round(lightness, 2)],
    }
