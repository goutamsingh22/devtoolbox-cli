"""Word splitting and case conversion helpers."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Callable

_ACRONYM_BOUNDARY = re.compile(r"([A-Z]+)([A-Z][a-z])")
_WORD_BOUNDARY = re.compile(r"([a-z0-9])([A-Z])")
_SEPARATOR = re.compile(r"[\W_]+", re.UNICODE)


def split_words(value: str) -> list[str]:
    """Split identifiers or prose into lowercase-agnostic words.

    Handles ``snake_case``, ``kebab-case``, ``camelCase``, ``PascalCase`` and
    acronym runs such as ``HTTPServer``.
    """
    text = _ACRONYM_BOUNDARY.sub(r"\1 \2", value)
    text = _WORD_BOUNDARY.sub(r"\1 \2", text)
    return [word for word in _SEPARATOR.split(text) if word]


def to_snake(value: str) -> str:
    return "_".join(word.lower() for word in split_words(value))


def to_kebab(value: str) -> str:
    return "-".join(word.lower() for word in split_words(value))


def to_dot(value: str) -> str:
    return ".".join(word.lower() for word in split_words(value))


def to_constant(value: str) -> str:
    return "_".join(word.upper() for word in split_words(value))


def to_camel(value: str) -> str:
    words = [word.lower() for word in split_words(value)]
    if not words:
        return ""
    return words[0] + "".join(word.capitalize() for word in words[1:])


def to_pascal(value: str) -> str:
    return "".join(word.lower().capitalize() for word in split_words(value))


def to_title(value: str) -> str:
    return " ".join(word.lower().capitalize() for word in split_words(value))


def to_upper(value: str) -> str:
    return value.upper()


def to_lower(value: str) -> str:
    return value.lower()


_CONVERTERS: dict[str, Callable[[str], str]] = {
    "snake": to_snake,
    "kebab": to_kebab,
    "dot": to_dot,
    "constant": to_constant,
    "camel": to_camel,
    "pascal": to_pascal,
    "title": to_title,
    "upper": to_upper,
    "lower": to_lower,
}


def convert(value: str, style: str) -> str:
    """Convert ``value`` to ``style`` (see :data:`_CONVERTERS`)."""
    try:
        converter = _CONVERTERS[style.strip().lower()]
    except KeyError as exc:
        available = ", ".join(sorted(_CONVERTERS))
        raise ValueError(f"unknown case style {style!r}; available: {available}") from exc
    return converter(value)


def slugify(value: str, separator: str = "-") -> str:
    """Turn text into a URL-friendly slug."""
    if not separator:
        raise ValueError("separator must not be empty")
    normalized = unicodedata.normalize("NFKD", value)
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    return separator.join(word.lower() for word in split_words(ascii_text))
