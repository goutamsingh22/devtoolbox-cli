"""DevToolbox - a small collection of utilities for everyday development.

The package is primarily a command line tool. Import the individual modules
(``devtoolbox.hashing``, ``devtoolbox.encoding``, ...) when you need the same
behaviour from Python code.
"""

from __future__ import annotations

__version__ = "0.1.0"
__author__ = "Goutam Singh"
__email__ = "25mcaa22@kristujayanti.com"
__license__ = "MIT"

__all__ = ["__version__"]
