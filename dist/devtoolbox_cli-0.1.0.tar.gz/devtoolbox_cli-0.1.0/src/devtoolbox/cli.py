"""Command-line interface for DevToolbox."""

from __future__ import annotations

import enum
import json as jsonlib
import sys
import uuid as uuidlib
from datetime import timezone
from pathlib import Path
from typing import Any, NoReturn, Optional

import typer

from . import __version__, hashing, jsonutil, jwtutil, netutil, secrets_util, textcase, timeutil
from . import color as colorutil
from . import encoding as encoding_util

app = typer.Typer(
    name="devtoolbox",
    help="A batteries-included toolbox of small utilities for everyday development.",
    epilog=(
        "Examples:\n\n"
        "  devtoolbox hash hello\n"
        "  devtoolbox base64 --decode aGVsbG8=\n"
        "  devtoolbox json '{\"b\": 1, \"a\": 2}' --sort-keys\n"
        "  devtoolbox timestamp 1704067200\n"
        "  devtoolbox password --length 32\n"
    ),
    no_args_is_help=True,
    add_completion=False,
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _strip_eol(value: str) -> str:
    if value.endswith("\r\n"):
        return value[:-2]
    if value.endswith(("\n", "\r")):
        return value[:-1]
    return value


def _read_text(text: Optional[str], file: Optional[Path]) -> str:
    if text is not None and file is not None:
        raise typer.BadParameter("Provide TEXT or --file, not both.")
    if file is not None:
        return _strip_eol(Path(file).read_text(encoding="utf-8"))
    if text is not None:
        return text
    if not sys.stdin.isatty():
        data = sys.stdin.read()
        if data:
            return _strip_eol(data)
    raise typer.BadParameter("Provide TEXT, --file, or pipe data via stdin.")


def _read_bytes(text: Optional[str], file: Optional[Path]) -> bytes:
    if text is not None and file is not None:
        raise typer.BadParameter("Provide TEXT or --file, not both.")
    if file is not None:
        return Path(file).read_bytes()
    return _read_text(text, None).encode("utf-8")


def _fail(exc: BaseException) -> NoReturn:
    typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
    raise typer.Exit(code=1)


def _echo_json(value: Any) -> None:
    typer.echo(jsonlib.dumps(value, indent=2, ensure_ascii=False))


def _show_version(value: bool) -> None:
    if value:
        typer.echo(f"devtoolbox {__version__}")
        raise typer.Exit()


@app.callback()
def _root(
    version: bool = typer.Option(
        False,
        "--version",
        callback=_show_version,
        is_eager=True,
        help="Show the installed version and exit.",
    ),
) -> None:
    """DevToolbox: small utilities for everyday development."""


@app.command()
def hash(
    text: Optional[str] = typer.Argument(None, help="Text to hash. Omit to read from stdin."),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Hash a file instead of text."),
    algorithm: str = typer.Option(
        "sha256",
        "--algorithm",
        "-a",
        help="Hash algorithm, for example sha256, sha512 or blake2b.",
    ),
    all_algorithms: bool = typer.Option(
        False,
        "--all",
        help="Show a digest for every algorithm guaranteed by hashlib.",
    ),
) -> None:
    """Hash text, stdin or a file."""
    try:
        if file is not None and text is not None:
            raise typer.BadParameter("Provide TEXT or --file, not both.")
        if all_algorithms:
            results = (
                hashing.hash_file_all(file)
                if file is not None
                else hashing.hash_text_all(_read_text(text, None))
            )
            for name in sorted(results):
                typer.echo(f"{name}: {results[name]}")
            return
        digest = (
            hashing.hash_file(file, algorithm)
            if file is not None
            else hashing.hash_text(_read_text(text, None), algorithm)
        )
    except typer.BadParameter:
        raise
    except (ValueError, OSError) as exc:
        _fail(exc)
    typer.echo(digest)


@app.command("uuid")
def uuid_command(
    count: int = typer.Option(1, "--count", "-n", min=1, help="How many UUIDs to generate."),
    kind: int = typer.Option(
        4,
        "--version",
        "-v",
        help="UUID version: 4 (random) or 1 (time-based; exposes the host MAC address).",
    ),
    upper: bool = typer.Option(False, "--upper", help="Uppercase the output."),
    no_dashes: bool = typer.Option(False, "--no-dashes", help="Remove hyphens."),
) -> None:
    """Generate UUIDs."""
    if kind not in (1, 4):
        raise typer.BadParameter("--version must be 1 or 4")

    for _ in range(count):
        rendered = str(uuidlib.uuid4() if kind == 4 else uuidlib.uuid1())
        if upper:
            rendered = rendered.upper()
        if no_dashes:
            rendered = rendered.replace("-", "")
        typer.echo(rendered)


@app.command("base64")
def base64_command(
    text: Optional[str] = typer.Argument(None, help="Input text. Omit to read from stdin."),
    decode: bool = typer.Option(False, "--decode", "-d", help="Decode instead of encode."),
    urlsafe: bool = typer.Option(
        False,
        "--urlsafe",
        help="Use the URL-safe alphabet (-_ instead of +/).",
    ),
    encoding: str = typer.Option(
        "utf-8",
        "--encoding",
        help="Text encoding for byte/text conversion.",
    ),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Read input from a file."),
) -> None:
    """Encode or decode base64."""
    try:
        if decode:
            decoded = encoding_util.decode_base64(_read_text(text, file), urlsafe=urlsafe)
            typer.echo(decoded.decode(encoding))
        else:
            typer.echo(encoding_util.encode_base64(_read_bytes(text, file), urlsafe=urlsafe))
    except (ValueError, OSError, LookupError) as exc:
        _fail(exc)


@app.command()
def url(
    text: Optional[str] = typer.Argument(None, help="Input text. Omit to read from stdin."),
    decode: bool = typer.Option(False, "--decode", "-d", help="Decode instead of encode."),
    plus: bool = typer.Option(False, "--plus", help="Use form encoding, where spaces become '+'."),
    encoding: str = typer.Option("utf-8", "--encoding", help="Text encoding."),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Read input from a file."),
) -> None:
    """Percent-encode or decode text."""
    try:
        source = _read_text(text, file)
        result = (
            encoding_util.url_decode(source, plus=plus, encoding=encoding)
            if decode
            else encoding_util.url_encode(source, plus=plus, encoding=encoding)
        )
    except typer.BadParameter:
        raise
    except (ValueError, OSError, LookupError) as exc:
        _fail(exc)
    typer.echo(result)


@app.command("hex")
def hex_command(
    text: Optional[str] = typer.Argument(None, help="Input text. Omit to read from stdin."),
    decode: bool = typer.Option(False, "--decode", "-d", help="Decode instead of encode."),
    encoding: str = typer.Option(
        "utf-8",
        "--encoding",
        help="Text encoding for byte/text conversion.",
    ),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Read input from a file."),
) -> None:
    """Encode or decode hexadecimal."""
    try:
        if decode:
            typer.echo(encoding_util.decode_hex(_read_text(text, file)).decode(encoding))
        else:
            typer.echo(encoding_util.encode_hex(_read_bytes(text, file)))
    except (ValueError, OSError, LookupError) as exc:
        _fail(exc)


@app.command("json")
def json_command(
    text: Optional[str] = typer.Argument(None, help="JSON text. Omit to read from stdin."),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Read JSON from a file."),
    minify: bool = typer.Option(False, "--minify", "-m", help="Remove all optional whitespace."),
    indent: int = typer.Option(2, "--indent", min=0, max=16, help="Indentation width."),
    sort_keys: bool = typer.Option(False, "--sort-keys", "-s", help="Sort object keys."),
    check: bool = typer.Option(False, "--check", help="Only validate the input."),
) -> None:
    """Validate and pretty-print or minify JSON."""
    try:
        value = jsonutil.loads(_read_text(text, file))
    except typer.BadParameter:
        raise
    except (ValueError, OSError) as exc:
        _fail(exc)

    if check:
        typer.echo("valid")
        return
    typer.echo(jsonutil.dumps(value, indent=indent, sort_keys=sort_keys, minify=minify))


@app.command()
def timestamp(
    value: Optional[str] = typer.Argument(
        None,
        help="Epoch number or ISO-8601 datetime. Omit to use the current time.",
    ),
    milliseconds: bool = typer.Option(False, "--ms", help="Use milliseconds instead of seconds."),
    unit: Optional[str] = typer.Option(
        None,
        "--unit",
        help="Force the unit of a numeric input: 's' or 'ms'.",
    ),
    local: bool = typer.Option(False, "--local", help="Use the local timezone instead of UTC."),
) -> None:
    """Convert between epoch timestamps and ISO-8601 datetimes."""
    try:
        if unit is not None and unit not in ("s", "ms"):
            raise typer.BadParameter("--unit must be 's' or 'ms'")
        tz = timeutil.local_timezone() if local else timezone.utc
        use_ms = milliseconds or unit == "ms"

        if value is None:
            typer.echo(timeutil.to_epoch(timeutil.now(tz), milliseconds=use_ms))
            return
        if timeutil.is_epoch(value):
            moment = timeutil.epoch_to_datetime(float(value), milliseconds=use_ms, tz=tz)
            typer.echo(moment.isoformat())
            return
        moment = timeutil.parse_datetime(value, default_tz=tz)
        typer.echo(timeutil.to_epoch(moment, milliseconds=use_ms))
    except typer.BadParameter:
        raise
    except (ValueError, OSError, OverflowError) as exc:
        _fail(exc)


@app.command()
def password(
    length: int = typer.Option(20, "--length", "-l", min=1, help="Password length."),
    count: int = typer.Option(1, "--count", "-n", min=1, help="How many passwords to generate."),
    symbols: bool = typer.Option(True, "--symbols/--no-symbols", help="Include symbols."),
    digits: bool = typer.Option(True, "--digits/--no-digits", help="Include digits."),
    upper: bool = typer.Option(True, "--upper/--no-upper", help="Include uppercase letters."),
    lower: bool = typer.Option(True, "--lower/--no-lower", help="Include lowercase letters."),
    exclude_ambiguous: bool = typer.Option(
        False,
        "--exclude-ambiguous",
        help="Remove characters that are easy to confuse (Il1O0o).",
    ),
    as_json: bool = typer.Option(False, "--json", help="Emit a JSON array with entropy estimates."),
) -> None:
    """Generate secure passwords."""
    try:
        passwords = [
            secrets_util.generate_password(
                length,
                symbols=symbols,
                digits=digits,
                upper=upper,
                lower=lower,
                exclude_ambiguous=exclude_ambiguous,
            )
            for _ in range(count)
        ]
        entropy = secrets_util.password_entropy(
            length,
            symbols=symbols,
            digits=digits,
            upper=upper,
            lower=lower,
            exclude_ambiguous=exclude_ambiguous,
        )
    except ValueError as exc:
        _fail(exc)

    if as_json:
        _echo_json(
            [
                {"password": item, "length": length, "entropy_bits": round(entropy, 2)}
                for item in passwords
            ]
        )
        return
    for item in passwords:
        typer.echo(item)


@app.command()
def token(
    nbytes: int = typer.Option(32, "--bytes", "-b", min=1, help="Entropy in bytes."),
    count: int = typer.Option(1, "--count", "-n", min=1, help="How many tokens to generate."),
    use_hex: bool = typer.Option(
        False,
        "--hex",
        help="Emit hexadecimal tokens instead of URL-safe tokens.",
    ),
) -> None:
    """Generate secure random tokens."""
    try:
        tokens = [secrets_util.generate_token(nbytes, use_hex=use_hex) for _ in range(count)]
    except ValueError as exc:
        _fail(exc)
    for item in tokens:
        typer.echo(item)


class CaseStyle(str, enum.Enum):
    snake = "snake"
    kebab = "kebab"
    dot = "dot"
    constant = "constant"
    camel = "camel"
    pascal = "pascal"
    title = "title"
    upper = "upper"
    lower = "lower"


@app.command("case")
def case_command(
    text: Optional[str] = typer.Argument(None, help="Text to convert. Omit to read from stdin."),
    to: CaseStyle = typer.Option(
        CaseStyle.snake,
        help="Target style.",
    ),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Read input from a file."),
) -> None:
    """Convert text between naming styles."""
    try:
        source = _read_text(text, file)
        converted = "\n".join(textcase.convert(line, to.value) for line in source.splitlines())
    except typer.BadParameter:
        raise
    except (ValueError, OSError) as exc:
        _fail(exc)
    typer.echo(converted)


@app.command()
def slug(
    text: Optional[str] = typer.Argument(None, help="Text to slugify. Omit to read from stdin."),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Read input from a file."),
    separator: str = typer.Option("-", "--separator", "-s", help="Separator between words."),
) -> None:
    """Turn text into a URL-friendly slug."""
    try:
        if not separator:
            raise typer.BadParameter("--separator must not be empty")
        typer.echo(textcase.slugify(_read_text(text, file), separator=separator))
    except typer.BadParameter:
        raise
    except (ValueError, OSError) as exc:
        _fail(exc)


@app.command()
def color(
    value: str = typer.Argument(..., help="Hex colour (#fff, #ffffff) or rgb(r, g, b)."),
    as_json: bool = typer.Option(False, "--json", help="Emit JSON."),
) -> None:
    """Convert a colour between hex, RGB and HSL."""
    try:
        info = colorutil.inspect(value)
    except ValueError as exc:
        _fail(exc)

    if as_json:
        _echo_json(info)
        return
    red, green, blue = info["rgb"]
    hue, saturation, lightness = info["hsl"]
    typer.echo(f"hex: {info['hex']}")
    typer.echo(f"rgb: {red}, {green}, {blue}")
    typer.echo(f"hsl: {hue:g}, {saturation:g}%, {lightness:g}%")


@app.command("jwt")
def jwt_command(
    token_value: str = typer.Argument(..., metavar="TOKEN", help="JWT to decode."),
    payload_only: bool = typer.Option(
        False,
        "--payload-only",
        "-p",
        help="Print only the decoded payload.",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress the 'signature not verified' warning.",
    ),
) -> None:
    """Decode a JWT. The signature is NOT verified."""
    try:
        decoded = jwtutil.decode(token_value)
    except ValueError as exc:
        _fail(exc)

    if not quiet:
        typer.secho("warning: the JWT signature is NOT verified", fg=typer.colors.YELLOW, err=True)

    if payload_only:
        _echo_json(decoded.payload)
        return
    document: dict[str, Any] = {"header": decoded.header, "payload": decoded.payload}
    if decoded.signature is not None:
        document["signature"] = decoded.signature
    _echo_json(document)


@app.command("ip")
def ip_command(
    value: str = typer.Argument(..., help="IPv4/IPv6 address or interface, e.g. 10.0.0.1/24."),
    as_json: bool = typer.Option(False, "--json", help="Emit JSON."),
) -> None:
    """Inspect an IP address or network interface."""
    try:
        info = netutil.inspect(value)
    except ValueError as exc:
        _fail(exc)

    if as_json:
        _echo_json(info)
        return
    for key, item in info.items():
        if item is None:
            continue
        if isinstance(item, bool):
            item = "yes" if item else "no"
        typer.echo(f"{key}: {item}")


@app.command()
def version() -> None:
    """Show the installed version."""
    typer.echo(f"devtoolbox {__version__}")


def main() -> None:
    """Entry point used by the ``devtoolbox`` console script."""
    app(prog_name="devtoolbox")


if __name__ == "__main__":
    main()
