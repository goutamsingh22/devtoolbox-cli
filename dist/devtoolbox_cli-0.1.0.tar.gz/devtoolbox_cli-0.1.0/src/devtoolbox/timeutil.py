"""Epoch and ISO-8601 conversion helpers."""

from __future__ import annotations

import re
from datetime import datetime, timezone, tzinfo
from typing import Optional

_NUMERIC = re.compile(r"^[+-]?(?:\d+\.?\d*|\.\d+)$")


def local_timezone() -> tzinfo:
    """Return the local timezone, falling back to UTC."""
    return datetime.now().astimezone().tzinfo or timezone.utc


def now(tz: Optional[tzinfo] = None) -> datetime:
    """Return the current datetime in ``tz`` (UTC by default)."""
    return datetime.now(tz or timezone.utc)


def is_epoch(value: str) -> bool:
    """Return ``True`` when ``value`` looks like an epoch number."""
    return bool(_NUMERIC.match(value.strip()))


def epoch_to_datetime(
    epoch: float,
    *,
    milliseconds: bool = False,
    tz: Optional[tzinfo] = None,
) -> datetime:
    """Convert an epoch value (seconds or milliseconds) to an aware datetime."""
    seconds = epoch / 1000.0 if milliseconds else epoch
    return datetime.fromtimestamp(seconds, tz=tz or timezone.utc)


def to_epoch(value: datetime, *, milliseconds: bool = False) -> int:
    """Convert a datetime to epoch seconds or milliseconds."""
    seconds = value.timestamp()
    return int(round(seconds * 1000)) if milliseconds else int(round(seconds))


def parse_datetime(text: str, *, default_tz: Optional[tzinfo] = None) -> datetime:
    """Parse an ISO-8601 datetime, accepting a trailing ``Z`` for UTC."""
    raw = text.strip()
    if not raw:
        raise ValueError("datetime must not be empty")
    if raw.endswith(("Z", "z")):
        raw = raw[:-1] + "+00:00"
    try:
        value = datetime.fromisoformat(raw)
    except ValueError as exc:
        raise ValueError(f"invalid ISO-8601 datetime: {text!r}") from exc
    if value.tzinfo is None:
        value = value.replace(tzinfo=default_tz or timezone.utc)
    return value
