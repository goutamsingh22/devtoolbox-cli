"""IP address and network inspection helpers."""

from __future__ import annotations

import ipaddress
from typing import Any, Union

Address = Union[ipaddress.IPv4Address, ipaddress.IPv6Address]


def _address_info(address: Address, value: str) -> dict[str, Any]:
    return {
        "input": value,
        "kind": "address",
        "version": address.version,
        "address": str(address),
        "compressed": address.compressed,
        "exploded": address.exploded,
        "is_private": address.is_private,
        "is_global": address.is_global,
        "is_loopback": address.is_loopback,
        "is_link_local": address.is_link_local,
        "is_multicast": address.is_multicast,
        "reverse_pointer": address.reverse_pointer,
    }


def inspect(value: str) -> dict[str, Any]:
    """Return details about an IP address or interface (``addr/prefix``)."""
    raw = value.strip()
    if not raw:
        raise ValueError("IP value must not be empty")

    try:
        if "/" in raw:
            interface = ipaddress.ip_interface(raw)
            address = interface.ip
            network = interface.network
            info = _address_info(address, value)
            info["kind"] = "interface"
            info.update(
                {
                    "network": network.with_prefixlen,
                    "network_address": str(network.network_address),
                    "netmask": str(network.netmask),
                    "prefixlen": network.prefixlen,
                    "num_addresses": network.num_addresses,
                }
            )
            if address.version == 4:
                info["broadcast_address"] = str(network.broadcast_address)
            return info

        return _address_info(ipaddress.ip_address(raw), value)
    except ValueError as exc:
        raise ValueError(f"invalid IP address or interface: {value!r}") from exc
