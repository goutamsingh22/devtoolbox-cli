"""JSON loading and formatting helpers."""

from __future__ import annotations

import json
from typing import Any


def loads(text: str) -> Any:
    """Parse JSON text, raising :class:`json.JSONDecodeError` on invalid input."""
    return json.loads(text)


def dumps(
    value: Any,
    *,
    indent: int = 2,
    sort_keys: bool = False,
    minify: bool = False,
) -> str:
    """Serialise ``value`` as human-friendly or compact JSON."""
    if minify:
        return json.dumps(
            value,
            separators=(",", ":"),
            sort_keys=sort_keys,
            ensure_ascii=False,
        )
    return json.dumps(value, indent=indent, sort_keys=sort_keys, ensure_ascii=False)
