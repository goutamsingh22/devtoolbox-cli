"""Base64, hexadecimal and URL encoding helpers."""

from __future__ import annotations

import base64
import binascii
import urllib.parse


def encode_base64(data: bytes, urlsafe: bool = False) -> str:
    """Return the base64 representation of ``data``."""
    encoder = base64.urlsafe_b64encode if urlsafe else base64.b64encode
    return encoder(data).decode("ascii")


def decode_base64(value: str, urlsafe: bool = False) -> bytes:
    """Decode base64 text, tolerating missing padding and surrounding whitespace."""
    compact = "".join(value.split())
    padding = "=" * (-len(compact) % 4)
    altchars = b"-_" if urlsafe else None
    try:
        return base64.b64decode(compact + padding, altchars=altchars, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError(f"invalid base64 input: {exc}") from exc


def encode_hex(data: bytes) -> str:
    """Return the lowercase hexadecimal representation of ``data``."""
    return data.hex()


def decode_hex(value: str) -> bytes:
    """Decode hexadecimal text (whitespace is ignored)."""
    try:
        return bytes.fromhex(value)
    except ValueError as exc:
        raise ValueError(f"invalid hex input: {exc}") from exc


def url_encode(text: str, plus: bool = False, encoding: str = "utf-8") -> str:
    """Percent-encode ``text``, optionally using form encoding."""
    encoder = urllib.parse.quote_plus if plus else urllib.parse.quote
    return encoder(text, safe="", encoding=encoding)


def url_decode(text: str, plus: bool = False, encoding: str = "utf-8") -> str:
    """Decode percent-encoded ``text``, optionally handling ``+`` as a space."""
    decoder = urllib.parse.unquote_plus if plus else urllib.parse.unquote
    return decoder(text, encoding=encoding)
