"""Secure password and token generation."""

from __future__ import annotations

import math
import secrets
import string
from collections.abc import Sequence

LOWERCASE = string.ascii_lowercase
UPPERCASE = string.ascii_uppercase
DIGITS = string.digits
SYMBOLS = "!@#$%^&*()-_=+[]{};:,.<>?/|~"
AMBIGUOUS = "Il1O0o"

_system_random = secrets.SystemRandom()


def _clean(text: str, exclude_ambiguous: bool) -> str:
    if not exclude_ambiguous:
        return text
    return "".join(char for char in text if char not in AMBIGUOUS)


def character_pool(
    *,
    symbols: bool = True,
    digits: bool = True,
    upper: bool = True,
    lower: bool = True,
    exclude_ambiguous: bool = False,
) -> str:
    """Return the set of characters a password may use."""
    parts: list[str] = []
    if lower:
        parts.append(_clean(LOWERCASE, exclude_ambiguous))
    if upper:
        parts.append(_clean(UPPERCASE, exclude_ambiguous))
    if digits:
        parts.append(_clean(DIGITS, exclude_ambiguous))
    if symbols:
        parts.append(_clean(SYMBOLS, exclude_ambiguous))
    pool = "".join(part for part in parts if part)
    if not pool:
        raise ValueError("at least one character class must be enabled")
    return pool


def generate_password(
    length: int = 20,
    *,
    symbols: bool = True,
    digits: bool = True,
    upper: bool = True,
    lower: bool = True,
    exclude_ambiguous: bool = False,
) -> str:
    """Generate a cryptographically secure password.

    The result is guaranteed to contain at least one character from every
    enabled class.
    """
    if length < 1:
        raise ValueError("length must be at least 1")

    classes: Sequence[str] = [
        _clean(text, exclude_ambiguous)
        for text, enabled in (
            (LOWERCASE, lower),
            (UPPERCASE, upper),
            (DIGITS, digits),
            (SYMBOLS, symbols),
        )
        if enabled
    ]
    classes = [text for text in classes if text]
    if not classes:
        raise ValueError("at least one character class must be enabled")
    if length < len(classes):
        raise ValueError(
            f"length must be at least {len(classes)} to include every selected character class"
        )

    pool = character_pool(
        symbols=symbols,
        digits=digits,
        upper=upper,
        lower=lower,
        exclude_ambiguous=exclude_ambiguous,
    )
    characters = [secrets.choice(text) for text in classes]
    characters.extend(secrets.choice(pool) for _ in range(length - len(classes)))
    _system_random.shuffle(characters)
    return "".join(characters)


def password_entropy(
    length: int = 20,
    *,
    symbols: bool = True,
    digits: bool = True,
    upper: bool = True,
    lower: bool = True,
    exclude_ambiguous: bool = False,
) -> float:
    """Return the theoretical entropy of a password in bits."""
    pool = character_pool(
        symbols=symbols,
        digits=digits,
        upper=upper,
        lower=lower,
        exclude_ambiguous=exclude_ambiguous,
    )
    return length * math.log2(len(pool))


def generate_token(nbytes: int = 32, *, use_hex: bool = False) -> str:
    """Generate a URL-safe token (or a hexadecimal token when ``use_hex``)."""
    if nbytes < 1:
        raise ValueError("nbytes must be at least 1")
    if use_hex:
        return secrets.token_hex(nbytes)
    return secrets.token_urlsafe(nbytes)
