"""Allow ``python -m devtoolbox`` to behave like the ``devtoolbox`` script."""

from __future__ import annotations

from .cli import main

if __name__ == "__main__":
    main()
