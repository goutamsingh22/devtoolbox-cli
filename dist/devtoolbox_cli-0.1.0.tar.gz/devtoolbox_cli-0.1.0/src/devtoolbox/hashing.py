"""Hashing helpers built on :mod:`hashlib`."""

from __future__ import annotations

import hashlib
from collections.abc import Iterable
from pathlib import Path
from typing import Optional, Union

_IGNORED = {"shake_128", "shake_256"}
ALGORITHMS: tuple[str, ...] = tuple(sorted(set(hashlib.algorithms_guaranteed) - _IGNORED))
_CHUNK_SIZE = 1024 * 1024

PathLike = Union[str, Path]


def _validate(algorithm: str) -> str:
    name = algorithm.strip().lower()
    if name in _IGNORED or name not in hashlib.algorithms_guaranteed:
        available = ", ".join(ALGORITHMS)
        raise ValueError(f"unknown algorithm {algorithm!r}; available: {available}")
    return name


def _validate_all(algorithms: Optional[Iterable[str]]) -> list[str]:
    source = ALGORITHMS if algorithms is None else algorithms
    return list(dict.fromkeys(_validate(name) for name in source))


def hash_bytes(data: bytes, algorithm: str = "sha256") -> str:
    """Return the hex digest of ``data`` using ``algorithm``."""
    return hashlib.new(_validate(algorithm), data).hexdigest()


def hash_text(text: str, algorithm: str = "sha256", encoding: str = "utf-8") -> str:
    """Return the hex digest of ``text`` encoded with ``encoding``."""
    return hash_bytes(text.encode(encoding), algorithm)


def hash_file(path: PathLike, algorithm: str = "sha256", chunk_size: int = _CHUNK_SIZE) -> str:
    """Return the hex digest of a file without loading it all into memory."""
    digest = hashlib.new(_validate(algorithm))
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def hash_text_all(
    text: str,
    algorithms: Optional[Iterable[str]] = None,
    encoding: str = "utf-8",
) -> dict[str, str]:
    """Return hex digests for every requested algorithm (all by default)."""
    data = text.encode(encoding)
    return {name: hashlib.new(name, data).hexdigest() for name in _validate_all(algorithms)}


def hash_file_all(
    path: PathLike,
    algorithms: Optional[Iterable[str]] = None,
    chunk_size: int = _CHUNK_SIZE,
) -> dict[str, str]:
    """Return hex digests for every requested algorithm, streaming the file once."""
    digests = {name: hashlib.new(name) for name in _validate_all(algorithms)}
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            for digest in digests.values():
                digest.update(chunk)
    return {name: digest.hexdigest() for name, digest in digests.items()}
