"""Minimal JWT decoder.

This module intentionally does **not** verify signatures. It is a debugging
tool for inspecting token headers and claims.
"""

from __future__ import annotations

import base64
import binascii
import json
from dataclasses import dataclass
from typing import Any, Optional


@dataclass(frozen=True)
class DecodedJwt:
    header: dict[str, Any]
    payload: dict[str, Any]
    signature: Optional[str]


def _decode_segment(segment: str, label: str) -> Any:
    padding = "=" * (-len(segment) % 4)
    try:
        raw = base64.b64decode(segment + padding, altchars=b"-_", validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError(f"invalid {label} segment: not valid base64url") from exc
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise ValueError(f"invalid {label} segment: not valid JSON") from exc


def decode(token: str) -> DecodedJwt:
    """Decode a JWT without verifying its signature."""
    parts = token.strip().split(".")
    if len(parts) not in (2, 3):
        raise ValueError("a JWT must have two or three dot-separated segments")

    header = _decode_segment(parts[0], "header")
    payload = _decode_segment(parts[1], "payload")
    if not isinstance(header, dict) or not isinstance(payload, dict):
        raise ValueError("JWT header and payload must be JSON objects")

    signature = parts[2] if len(parts) == 3 else None
    return DecodedJwt(header=header, payload=payload, signature=signature)
